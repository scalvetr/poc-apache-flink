package com.github.scalvetr.poc.flink.datagen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DatagenApplicationTests {

	@Test
	void contextLoads() {
	}

}
